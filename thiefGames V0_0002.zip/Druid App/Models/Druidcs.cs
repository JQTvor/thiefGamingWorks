﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Druid_App.Models
{
    public class Druidcs
    {
            public int DruidLevel { get; set; }
            public int Strength { get; set; }
            public int Dexterity { get; set; }
            public int Constitution { get; set; }
            public int AC { get; set; }
            public string MorphType { get; set; }
            public string CreatureType { get; set; }
            public string CreatureSize { get; set; }
            public string PlayerSize { get; set; }


    }
}