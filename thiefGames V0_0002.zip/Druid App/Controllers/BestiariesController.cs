﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Druid_App.Models;
using PagedList;

namespace Druid_App.Controllers
{
    public class BestiariesController : Controller
    {
        private PathfinderEntities db = new PathfinderEntities();

        // GET: Bestiaries
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {

            int pageSize = 100000;
            int pageNumber = (page ?? 1);
            return View(db.Bestiaries.ToList().ToPagedList(pageNumber, pageSize));
            //return View(db.Bestiaries.ToList());
        }


















        // GET: Bestiaries/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bestiary bestiary = db.Bestiaries.Find(id);
            if (bestiary == null)
            {
                return HttpNotFound();
            }

            return View(bestiary);
        }

        // GET: Bestiaries/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Bestiaries/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Name,CR,XP,Race,Class1,Class1_Lvl,Class2,Class2_Lvl,Alignment,Size,Type,subtype1,subtype2,subtype3,subtype4,subtype5,subtype6,AC,AC_Touch,AC_Flat_footed,HP,HD,Fort,Ref,Will,Melee,Ranged,Space,Reach,Str,Dex,Con,Int,Wis,Cha,Feats,Skills,RacialMods,Languages,SQ,Environment,Organization,Treasure,Group,Gear,OtherGear,CharacterFlag,CompanionFlag,Speed,Base_Speed,Fly_Speed,Maneuverability,Climb_Speed,Swim_Speed,Burrow_Speed,Speed_Special,Speed_Land,Fly,Climb,Burrow,Swim,VariantParent,ClassArchetypes,CompanionFamiliarLink,AlternateNameForm,id,UniqueMonster,MR,Mythic,MT,Source")] Bestiary bestiary)
        {
            if (ModelState.IsValid)
            {
                db.Bestiaries.Add(bestiary);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(bestiary);
        }

        // GET: Bestiaries/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bestiary bestiary = db.Bestiaries.Find(id);
            if (bestiary == null)
            {
                return HttpNotFound();
            }
            return View(bestiary);
        }

        // POST: Bestiaries/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Name,CR,XP,Race,Class1,Class1_Lvl,Class2,Class2_Lvl,Alignment,Size,Type,subtype1,subtype2,subtype3,subtype4,subtype5,subtype6,AC,AC_Touch,AC_Flat_footed,HP,HD,Fort,Ref,Will,Melee,Ranged,Space,Reach,Str,Dex,Con,Int,Wis,Cha,Feats,Skills,RacialMods,Languages,SQ,Environment,Organization,Treasure,Group,Gear,OtherGear,CharacterFlag,CompanionFlag,Speed,Base_Speed,Fly_Speed,Maneuverability,Climb_Speed,Swim_Speed,Burrow_Speed,Speed_Special,Speed_Land,Fly,Climb,Burrow,Swim,VariantParent,ClassArchetypes,CompanionFamiliarLink,AlternateNameForm,id,UniqueMonster,MR,Mythic,MT,Source")] Bestiary bestiary)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bestiary).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(bestiary);
        }

        // GET: Bestiaries/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bestiary bestiary = db.Bestiaries.Find(id);
            if (bestiary == null)
            {
                return HttpNotFound();
            }
            return View(bestiary);
        }

        // POST: Bestiaries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Bestiary bestiary = db.Bestiaries.Find(id);
            db.Bestiaries.Remove(bestiary);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
