﻿using Druid_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;

namespace Druid_App.Controllers
{
    public class HomeController : Controller
    {

        // Size Change for AC, and AB
        int acSizeChange, abSizeChange;
        // Changes in Attributes by size
        int dexSizeChange, strSizeChange, conSizeChange;
        // Changes in Attributes by Spell
        int dexSpellChange, strSpellChange, conSpellChange;
        //Natural Armor Change
        int acSpellNatural;
        // Mathed changes
        int dexModifer, strModifier, conModifier;
        // Get Set Data
        int iAC, iStrength, iDexterity, iConstitution, iLevel;


        private PathfinderEntities db = new PathfinderEntities();
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Druid(Druidcs i, string sortOrder, string currentFilter, string searchString, int? page)
        {

            int pageSize = 99999999;
            int pageNumber = (page ?? 1);
            int inputAC = i.AC;
            ViewBag.Level = i.DruidLevel;



//4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444
            if (i.DruidLevel >= 4)
            {
                if (i.MorphType == "SmallAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange =   0;
                        abSizeChange =   0;


                        dexSizeChange =  0;
                        strSizeChange =  0;
                        conSizeChange =  0;

                        dexSpellChange = 2;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 1;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);


                    }
                    if(i.PlayerSize == "Medium")
                    {
                            acSizeChange = 1;
                            abSizeChange = 1;


                            dexSizeChange = 0;
                            strSizeChange = 0;
                            conSizeChange = 0;

                            acSpellNatural = 1;
                            dexSpellChange = 2;
                            strSpellChange = 0;
                            conSpellChange = 0;

                            iAC = i.AC;
                            iConstitution = i.Constitution;
                            iStrength = i.Strength;
                            iDexterity = i.Dexterity;
                            iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureType = "Animal";
                    i.CreatureSize = "Small";
                return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));

                }
                if (i.MorphType == "MediumAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {

                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureSize = "Medium";
                    i.CreatureType = "Animal";
                return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));

                }

            }

            //666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
            if (i.DruidLevel >= 6)
            {
                if (i.MorphType == "TinyAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 1;
                        abSizeChange = 1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = -2;
                        conSpellChange = 0;
                        acSpellNatural = 1;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 2;
                        abSizeChange = 2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = -2;
                        conSpellChange = 0;
                        acSpellNatural = 1;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureSize = "Tiny";
                    i.CreatureType = "Animal";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));
                }
                if (i.MorphType == "LargeAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureSize = "Large";
                    i.CreatureType = "Animal";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));
                }
                if (i.MorphType == "SAirEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 2;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 2;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Small";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Fly Speed 60(Perfect), Darkvision 60 feet, Create a Whirlwind";
                }
                if (i.MorphType == "SEarthEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Small";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Ability to Earth Glide";
                }
                if (i.MorphType == "SFireEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 2;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 2;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 2;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Small";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Resist fire 20, Vulnerability to Cold, Burn Ability.";
                }
                if (i.MorphType == "SWaterEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 0;
                        conSpellChange = 2;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 0;
                        conSpellChange = 2;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Small";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Swim 60 feet, Darkvision 60 feet, Create a Vortex, Ability to Breathe water";
                }

            }

//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
            if (i.DruidLevel >= 8)
            {
                if (i.MorphType == "DimAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = 2;
                        abSizeChange = 2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = -4;
                        conSpellChange = 0;
                        acSpellNatural = 1;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 3;
                        abSizeChange = 3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = -4;
                        conSpellChange = 0;
                        acSpellNatural = 1;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureSize = "Diminutive";
                    i.CreatureType = "Animal";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));
                }
                if (i.MorphType == "HugeAnimal")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -3;
                        abSizeChange = -3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -4;
                        strSpellChange = 6;
                        conSpellChange = 0;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -4;
                        strSpellChange = 6;
                        conSpellChange = 0;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }

                    i.CreatureSize = "Huge";
                    i.CreatureType = "Animal";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));
                }
                if (i.MorphType == "MAirEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 3;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 3;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Medium";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Fly Speed 60(Perfect), Darkvision 60 feet, Create a Whirlwind";
                }
                if (i.MorphType == "MEarthEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 5;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 5;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Medium";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Ability to Earth Glide";
                }
                if (i.MorphType == "MFireEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 3;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 0;
                        acSpellNatural = 3;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Medium";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Resist fire 20, Vulnerability to Cold, Burn Ability.";
                }
                if (i.MorphType == "MWaterEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 0;
                        conSpellChange = 4;
                        acSpellNatural = 5;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);

                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = 0;
                        abSizeChange = 0;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 0;
                        strSpellChange = 0;
                        conSpellChange = 4;
                        acSpellNatural = 5;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Medium";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Swim 60 feet, Darkvision 60 feet, Create a Vortex, Ability to Breathe water";
                }
                if (i.MorphType == "SmallPlant")
                {
                    i.Dexterity = i.Dexterity + 0;
                    ViewBag.Dexterity = i.Dexterity;
                    i.Strength = i.Strength + 0;
                    ViewBag.Strength = i.Strength;
                    i.Constitution = i.Constitution + 2;
                    ViewBag.Constitution = i.Constitution;
                    i.AC = i.AC + 2;
                    ViewBag.AC = i.AC;
                    i.CreatureSize = "Small";
                    i.CreatureType = "Plant";
                    ViewBag.SQ = "Speed 5 Feet, No other forms of movement.";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));

                }
                if (i.MorphType == "MediumPlant")
                {
                    i.Dexterity = i.Dexterity + 2;
                    ViewBag.Dexterity = i.Dexterity;
                    i.Strength = i.Strength + 0;
                    ViewBag.Strength = i.Strength;
                    i.Constitution = i.Constitution + 2;
                    ViewBag.Constitution = i.Constitution;
                    i.AC = i.AC + 2;
                    ViewBag.AC = i.AC;
                    i.CreatureSize = "Medium";
                    i.CreatureType = "Plant";
                    ViewBag.SQ = "Speed 5 Feet, No other forms of movement.";
                    return View(db.Bestiaries.Where(x => x.Type == i.CreatureType && (x.Size == i.CreatureSize)).ToList().ToPagedList(pageNumber, pageSize));
                }
            }
 
//10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  10  
            if (i.DruidLevel >= 10)
            {
                if (i.MorphType == "LAirEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 2;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Large";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Fly Speed 60(Perfect), Darkvision 60 feet, Create a Whirlwind, Immune to Bleed Damage, Critical hHits, and Sneak Attacks ";
                }
                if (i.MorphType == "LEarthEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 6;
                        conSpellChange = 2;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 6;
                        conSpellChange = 2;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Large";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Ability to Earth Glide, Immune to Bleed Damage, Critical Hits, and Sneak Attacks";
                }
                if (i.MorphType == "LFireEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 2;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 4;
                        strSpellChange = 0;
                        conSpellChange = 2;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Large";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Resist fire 20, Vulnerability to Cold, Burn Ability, Immune to Bleed Damage, Critical Hits, and Sneak Attacks";
                }
                if (i.MorphType == "LWaterEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = +2;
                        conSpellChange = 6;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -1;
                        abSizeChange = -1;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 2;
                        conSpellChange = 6;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Large";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Swim 60 feet, Darkvision 60 feet, Create a Vortex, Ability to Breathe water, Immune to Bleed Damage, Critical Hits, and Sneak Attacks";
                }
            }

//12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  12  
            if (i.DruidLevel >= 12)
            {
                if (i.MorphType == "HAirEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -3;
                        abSizeChange = -3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = 4;
                        conSpellChange = 0;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Huge";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Fly Speed 120(Perfect), Darkvision 60 feet, Create a Whirlwind, Immune to Bleed Damage, Critical hHits, and Sneak Attacks, DR 5/—";
                }
                if (i.MorphType == "HEarthEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -3;
                        abSizeChange = -3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 8;
                        conSpellChange = 4;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 8;
                        conSpellChange = 4;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Huge";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Ability to Earth Glide, Immune to Bleed Damage, Critical Hits, and Sneak Attacks, DR 5/—,";
                }
                if (i.MorphType == "HFireEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -3;
                        abSizeChange = -3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = 0;
                        conSpellChange = 4;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = 6;
                        strSpellChange = 0;
                        conSpellChange = 4;
                        acSpellNatural = 4;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Huge";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Darkvision 60 feet, Resist fire 20, Vulnerability to Cold, Burn Ability, Immune to Bleed Damage, Critical Hits, and Sneak Attacks, DR 5/—";
                }
                if (i.MorphType == "HWaterEle")
                {
                    if (i.PlayerSize == "Small")
                    {
                        acSizeChange = -3;
                        abSizeChange = -3;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 4;
                        conSpellChange = 8;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    if (i.PlayerSize == "Medium")
                    {
                        acSizeChange = -2;
                        abSizeChange = -2;

                        dexSizeChange = 0;
                        strSizeChange = 0;
                        conSizeChange = 0;

                        dexSpellChange = -2;
                        strSpellChange = 4;
                        conSpellChange = 8;
                        acSpellNatural = 6;

                        iAC = i.AC;
                        iConstitution = i.Constitution;
                        iStrength = i.Strength;
                        iDexterity = i.Dexterity;
                        iLevel = i.DruidLevel;

                        BeastShape(iLevel, iAC, iDexterity, iConstitution, acSizeChange, abSizeChange, acSpellNatural, dexSizeChange, strSizeChange, conSizeChange, dexSpellChange, strSpellChange, conSpellChange);
                    }
                    i.CreatureSize = "Huge";
                    i.CreatureType = "Outsider";
                    ViewBag.SQ = "Swim 120 feet, Darkvision 60 feet, Create a Vortex, Ability to Breathe water, Immune to Bleed Damage, Critical Hits, and Sneak Attacks, DR 5/—";
                }
            }

            return View(db.Bestiaries.ToList().ToPagedList(pageNumber, pageSize));


        }

        private void BeastShape(int iLevel, int iAC, int iDexterity, int iConstitution, int acSizeChange, int abSizeChange, int acSpellNatural, int dexSizeChange, int strSizeChange, int conSizeChange, int dexSpellChange, int strSpellChange, int conSpellChange)
        {
            dexModifer = (dexSpellChange + dexSizeChange) / 2;
            strModifier = (strSpellChange + strSizeChange) / 2;
            conModifier = (conSpellChange + conSizeChange) / 2;

            ViewBag.AddedStr = iStrength + ", Size Change +" + strSizeChange + ", Spell Change +" + strSpellChange;
            ViewBag.Strength = iStrength + strSizeChange + strSpellChange;

            ViewBag.AddedCon = iConstitution + ", Size Change +" + conSizeChange + ", Spell Change +" + conSpellChange;
            ViewBag.Constitution = iConstitution + conSizeChange + conSpellChange;

            ViewBag.AddedDex = iDexterity + ", Size Change +" + dexSizeChange + ", Spell Change +" + dexSpellChange;
            ViewBag.Dexterity = iDexterity + dexSizeChange + dexSpellChange;

            ViewBag.AddedAC = iAC + ", size change +" + acSizeChange + ", Dex Mod +" + dexModifer + ", Natural +" + acSpellNatural;
            ViewBag.AC = iAC + acSpellNatural + dexModifer + acSizeChange;

            ViewBag.AddedAB = "Size Change +" + abSizeChange + ", Strength Change +" + strModifier;
            ViewBag.MeleeBonus = strModifier + abSizeChange;

            ViewBag.AddedDamage = "Str By Size +" + strSizeChange + ", Str By Spell +" + strSpellChange;
            ViewBag.DamageBonus = strModifier;

            ViewBag.AddedHP = "Level "+ iLevel +" * Added Con Modifier " + conModifier;
            ViewBag.TotalHP = iLevel * conModifier;
        }
    }
}
